class Performer extends Artist{
    public Performer(String people_id, String name, String surname, String country) {
        super(people_id, name, surname, country);
    }
}
